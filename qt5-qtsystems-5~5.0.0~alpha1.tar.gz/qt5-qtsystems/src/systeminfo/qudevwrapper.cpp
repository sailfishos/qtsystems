/****************************************************************************
**
** Copyright (C) 2012 Nokia Corporation and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/
**
** This file is part of the QtSystems module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL$
** GNU Lesser General Public License Usage
** This file may be used under the terms of the GNU Lesser General Public
** License version 2.1 as published by the Free Software Foundation and
** appearing in the file LICENSE.LGPL included in the packaging of this
** file. Please review the following information to ensure the GNU Lesser
** General Public License version 2.1 requirements will be met:
** http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Nokia gives you certain additional
** rights. These rights are described in the Nokia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU General
** Public License version 3.0 as published by the Free Software Foundation
** and appearing in the file LICENSE.GPL included in the packaging of this
** file. Please review the following information to ensure the GNU General
** Public License version 3.0 requirements will be met:
** http://www.gnu.org/copyleft/gpl.html.
**
** Other Usage
** Alternatively, this file may be used in accordance with the terms and
** conditions contained in a signed written agreement between you and Nokia.
**
**
**
**
**
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "qudevwrapper_p.h"

#include <QSocketNotifier>

#include <poll.h>
#include <sys/select.h>

#if !defined(QT_NO_UDEV)

QT_BEGIN_NAMESPACE

QUDevWrapper::QUDevWrapper(QObject *parent)
    : QObject(parent)
    , udev(0)
    , udevMonitor(0)
    , udevFd(-1)
    , notifier(0)
    , watcherEnabled(false)
    , watchPowerSupply(false)
    , watchDrives(false)
{
}

bool QUDevWrapper::addUDevWatcher(const QByteArray &subsystem)
{
    if (!udev)
        udev = udev_new();

    if (udev && !udevMonitor)
        udevMonitor = udev_monitor_new_from_netlink(udev, "udev");

    if (udevMonitor) {
        if (udev_monitor_filter_add_match_subsystem_devtype(udevMonitor, subsystem, NULL) >= 0) {
            if (!watcherEnabled) {
                if (udev_monitor_enable_receiving(udevMonitor) >= 0) {
                    udevFd = udev_monitor_get_fd(udevMonitor);
                    if (udevFd >= 0) {
                        notifier = new QSocketNotifier(udevFd, QSocketNotifier::Read, this);
                        if (connect(notifier, SIGNAL(activated(int)), this, SLOT(onUDevChanges()))) {
                            watcherEnabled = true;
                            return true;
                        }
                    }
                }
            } else {
                if (udev_monitor_filter_update(udevMonitor) >= 0)
                    return true;
            }
        }
    }
    return false;
}

bool QUDevWrapper::removeAllUDevWatcher()
{
    if (!udev || !udevMonitor)
        return true;

    if (udev_monitor_filter_remove(udevMonitor) >= 0) {
        if (udev_monitor_filter_update(udevMonitor) >= 0)
            return true;
    }
    return false;
}

void QUDevWrapper::connectNotify(const char *signal)
{
    if (!watchDrives && strcmp(signal, SIGNAL(driveChanged())) == 0) {
        if (addUDevWatcher("block"))
            watchDrives = true;
    } else if (!watchPowerSupply && (strcmp(signal, SIGNAL(batteryDataChanged(int,QByteArray,QByteArray))) == 0
                                     || strcmp(signal, SIGNAL(chargerTypeChanged(QByteArray,bool))) == 0)) {
        if (addUDevWatcher("power_supply"))
            watchPowerSupply = true;
    }
}
void QUDevWrapper::disconnectNotify(const char *signal)
{
    if (watchDrives && strcmp(signal, SIGNAL(driveChanged())) == 0) {
        if (removeAllUDevWatcher()) {
            watchDrives = false;
            if (watchPowerSupply) {
                if (!addUDevWatcher("power_supply"))
                    watchPowerSupply = false;
            }
        }
    } else if (watchPowerSupply && (strcmp(signal, SIGNAL(batteryDataChanged(int,QByteArray,QByteArray))) == 0
                                    || strcmp(signal, SIGNAL(chargerTypeChanged(QByteArray,bool))) == 0)) {
        if (removeAllUDevWatcher()) {
            watchPowerSupply = false;
            if (watchDrives) {
                if (!addUDevWatcher("block"))
                    watchDrives = false;
            }
        }
    }

    if (!watchDrives && !watchPowerSupply) {
        disconnect(notifier, SIGNAL(activated(int)), this, SLOT(onUDevChanges()));
        udev_monitor_unref(udevMonitor);
        udevMonitor = 0;
        udevFd = -1;
        watcherEnabled = false;
    }
}

void QUDevWrapper::onUDevChanges()
{
    int ret;
    struct udev_device *device = 0;
    QByteArray subsystem;
    QByteArray action;
    QByteArray sysname;
    struct pollfd pollfds[1];

    pollfds[0].fd = udevFd;
    pollfds[0].events = POLLIN;
    pollfds[0].revents = 0;
    ret = poll(pollfds, 1, -1);

    if ((pollfds[0].revents & POLLIN) && ret == 1) {
        device = udev_monitor_receive_device(udevMonitor);
        if (device) {
            subsystem = udev_device_get_subsystem(device);
            action = udev_device_get_action(device);
            sysname = udev_device_get_sysname(device);

            if (qstrcmp(subsystem, "block") == 0
                    && ((qstrcmp(action, "add") == 0) || qstrcmp(action, "remove") == 0)) {
                emit driveChanged();
            } else if (qstrcmp(subsystem, "power_supply") == 0) {
                int i = -1;
                if (sysname.contains("AC")) {
                    bool enabled = false;
                    if (qstrcmp(udev_device_get_sysattr_value(device, "online"), "1") == 0)
                        enabled = true;
                    emit chargerTypeChanged("AC", enabled);
                } else if (sysname.contains("USB")) {
                    bool enabled = false;
                    QByteArray charger(udev_device_get_sysattr_value(device, "type"));
                    if (qstrcmp(udev_device_get_sysattr_value(device, "present"), "1") == 0)
                        enabled = true;
                    emit chargerTypeChanged(charger, enabled);
                } else if (sysname.contains("BAT")) {
                    bool ok;
                    i = sysname.right(1).toInt(&ok);
                    if (!ok)
                        i = -1;
                }

                if (i > -1) {
                    QByteArray status(udev_device_get_sysattr_value(device, "status"));
                    if (!status.isEmpty())
                        emit batteryDataChanged(i, "status", status);

                    QByteArray remainingCapacity(udev_device_get_sysattr_value(device, "charge_now"));
                    if (!remainingCapacity.isEmpty())
                        emit batteryDataChanged(i, "charge_now", remainingCapacity);

                    QByteArray remainingChargingTime(udev_device_get_sysattr_value(device, "time_to_full_avg"));
                    if (!remainingChargingTime.isEmpty())
                        emit batteryDataChanged(i, "time_to_full_avg", remainingChargingTime);

                    QByteArray voltage(udev_device_get_sysattr_value(device, "voltage_now"));
                    if (!voltage.isEmpty())
                        emit batteryDataChanged(i, "voltage_now", voltage);

                    QByteArray currentFlow(udev_device_get_sysattr_value(device, "current_now"));
                    if (!currentFlow.isEmpty())
                        emit batteryDataChanged(i, "current_now", currentFlow);

                    QByteArray batteryStatus(udev_device_get_sysattr_value(device, "capacity_level"));
                    if (!batteryStatus.isEmpty())
                        emit batteryDataChanged(i, "capacity_level", batteryStatus);
                }
            }
        }
    }
}

QT_END_NAMESPACE

#endif // QT_NO_UDEV
